class Note{

  static noteSize;//size are equal
  constructor(notePos,noteState) {
    this.notePos = notePos;//an array for position
    this.noteState = noteState;//an array for state
  }
}